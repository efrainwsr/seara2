<?php 
session_start();
if(isset($_SESSION['usuario']) and $_SESSION['usuario']=='admin'){
	?>
	<!DOCTYPE html>
	<html>
	<head>
		<title>usuarios</title>
		<?php require_once "menu.php"; ?>
	</head>
	<body>
		<div class="container">
			<h1>Administrar usuarios</h1>
			<div class="row">
				<div class="col-sm-4">
					<form id="frmRegistro" name="frmRegistro">
						<label>Nombre</label>
						<input type="text" class="form-control input-sm" name="nombre" id="nombre" placeholder="Juan" maxlength="30" onkeypress="return soloLetras(event)" />
						<div id="mensaje1" class="errores"> Campo Requerido</div>

						<label>Apellido</label>
						<input type="text" class="form-control input-sm" name="apellido" id="apellido" placeholder="Narvaez" maxlength="30" onkeypress="return soloLetras(event)" />
						<div id="mensaje2" class="errores"> Campo Requerido</div>

						<label>Usuario</label>
						<input type="text" class="form-control input-sm" name="usuario" id="usuario" placeholder="juan.narv" maxlength="15">
						<div id="mensaje3" class="errores"> Campo Requerido</div>

						<label>Password</label>
						<input type="text" class="form-control input-sm" name="password" id="password" placeholder="contraseña secreta" maxlength="15">
						<div id="mensaje4" class="errores"> Campo Requerido</div>
						<p></p>
						<button class="btn btn-primary" id="registro">Registrar</button>

					</form>
				</div>
				<div class="col-sm-8">
					<div id="tablaUsuariosLoad"></div>
				</div>
			</div>
		</div>


		<!-- Button trigger modal -->


		<!-- Modal -->
		<div class="modal fade" id="actualizaUsuarioModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<div class="modal-dialog modal-sm" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title" id="myModalLabel">Actualiza Usuario</h4>
					</div>
					<div class="modal-body">
						<form id="frmRegistroU" name="frmRegistroU">
							<input type="text" hidden="" id="idUsuario" name="idUsuario">
							<label>Nombre</label>
							<input type="text" class="form-control input-sm" name="nombreU" id="nombreU" maxlength="30" onkeypress="return soloLetras(event)" />
							<div id="mensaje11" class="errores"> Campo Requerido</div>
							<label>Apellido</label>
							<input type="text" class="form-control input-sm" name="apellidoU" id="apellidoU" maxlength="30" onkeypress="return soloLetras(event)" />
							<div id="mensaje22" class="errores"> Campo Requerido</div>
							<label>Usuario</label>
							<input type="text" class="form-control input-sm" name="usuarioU" id="usuarioU" maxlength="15">
							<div id="mensaje33" class="errores"> Campo Requerido</div>

						</form>
					</div>
					<div class="modal-footer">
						<button id="btnActualizaUsuario" name="btnActualizaUsuario" type="button" class="btn btn-warning" data-dismiss="modal">Actualiza Usuario</button>

					</div>
				</div>
			</div>
		</div>

	</body>
	</html>

	<script type="text/javascript">
		function agregaDatosUsuario(idusuario){

			$.ajax({
				type:"POST",
				data:"idusuario=" + idusuario,
				url:"../procesos/usuarios/obtenDatosUsuario.php",
				success:function(r){
					dato=jQuery.parseJSON(r);

					$('#idUsuario').val(dato['id_usuario']);
					$('#nombreU').val(dato['nombre']);
					$('#apellidoU').val(dato['apellido']);
					$('#usuarioU').val(dato['email']);
				}
			});
		}

		function eliminarUsuario(idusuario){
			alertify.confirm('¿Desea eliminar este usuario?', function(){ 
				$.ajax({
					type:"POST",
					data:"idusuario=" + idusuario,
					url:"../procesos/usuarios/eliminarUsuario.php",
					success:function(r){
						if(r==1){
							$('#tablaUsuariosLoad').load('usuarios/tablaUsuarios.php');
							alertify.success("Eliminado con exito.");
						}else{
							alertify.error("No se pudo eliminar.");
						}
					}
				});
			}, function(){ 
				alertify.error('Cancelado.')
			});
		}

		function ocultarUsuario(idusuario){
			alertify.confirm('¿Desea eliminar este usuario?', function(){ 
				$.ajax({
					type:"POST",
					data:"idusuario=" + idusuario,
					url:"../procesos/usuarios/removerUsuario.php",
					success:function(r){
						if(r==1){
							$('#tablaUsuariosLoad').load('usuarios/tablaUsuarios.php');
							alertify.success("Eliminado con exito.");
						}else{
							alertify.error("No se pudo eliminar.");
						}
					}
				});
			}, function(){ 
				alertify.error('Cancelado.')
			});
		}


	</script>

	<script type="text/javascript">
		$(document).ready(function(){
			$('#btnActualizaUsuario').click(function(){

				vacios=validarFormVacio('frmRegistroU');

				if(vacios > 0){
					//alertify.alert("Debes llenar todos los campos!");
					return false;
				}

				datos=$('#frmRegistroU').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../procesos/usuarios/actualizaUsuario.php",
					success:function(r){

						if(r==1){
							$('#tablaUsuariosLoad').load('usuarios/tablaUsuarios.php');
							alertify.success("Modificacion exitosa.");
						}else{
							alertify.error("No se pudo modificar.");
						}
					}
				});
			});
		});
	</script>

	<script type="text/javascript">
		$(document).ready(function(){

			$('#tablaUsuariosLoad').load('usuarios/tablaUsuarios.php');

			$('#registro').click(function(){

				vacios=validarFormVacio('frmRegistro');

				if(vacios > 0){
					//alertify.alert("Debes llenar todos los campos!");
					return false;
				}

				datos=$('#frmRegistro').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../procesos/regLogin/registrarUsuario.php",
					success:function(r){
						//alert(r);

						if(r==1){
							$('#frmRegistro')[0].reset();
							$('#tablaUsuariosLoad').load('usuarios/tablaUsuarios.php');
							alertify.success("Agregado con exito.");
						}else{
							alertify.error("Fallo al agregar.");
						}
					}
				});
			});
		});
	</script>

<script>
        
        $(document).ready(function(){
            //función click
            $("#registro").click(function(){
                var nombre = $("#nombre").val();
                var apellido = $("#apellido").val();
                var usuario = $("#usuario").val();
                var password = $("#password").val();
               
                if(nombre == ""){
                    $("#mensaje1").fadeIn("slow");
                    document.frmRegistro.nombre.focus()
                    return false;
                }else{
                	$("#mensaje1").fadeOut();
                }
                    if(apellido == ""){
                        $("#mensaje2").fadeIn("slow");
                        document.frmRegistro.apellido.focus()
                        return false;
                    }
                    else{
                        $("#mensaje2").fadeOut();
 			}
                        if(usuario == ""){
                            $("#mensaje3").fadeIn("slow");
                            document.frmRegistro.telefono.focus()
                            return false;
                        }
                        else{
                            $("#mensaje3").fadeOut();
                        }
                        if(password == ""){
                            $("#mensaje4").fadeIn("slow");
                            document.frmRegistro.password.focus()
                            return false;
                        }
                        else{
                            $("#mensaje4").fadeOut();
                        }
                    
            });//click
       });//ready
    </script>

    <script>
        
        $(document).ready(function(){
            //función click
            $("#btnActualizaUsuario").click(function(){
                var nombreU = $("#nombreU").val();
                var apellidoU = $("#apellidoU").val();
                var usuarioU = $("#usuarioU").val();         
                if(nombreU == ""){
                    $("#mensaje11").fadeIn("slow");
                    document.frmRegistroU.nombre.focus()
                    return false;
                }else{
                	$("#mensaje1").fadeOut();
                }
                    if(apellidoU == ""){
                        $("#mensaje22").fadeIn("slow");
                        document.frmRegistroU.apellidoU.focus()
                        return false;
                    }
                    else{
                        $("#mensaje2").fadeOut();
 			}
                        if(usuarioU == ""){
                            $("#mensaje33").fadeIn("slow");
                            document.frmRegistroU.usuarioU.focus()
                            return false;
                        }
                        else{
                            $("#mensaje33").fadeOut();
                        }
                    
            });//click
       });//ready
    </script>



	<script type="text/javascript">
			soloLetras();
		</script>

	<?php 
}else{
	header("location:../index.php");
}
?>