<?php 
	
	require_once "../../clases/Conexion.php";
	$c= new conectar();
	$conexion=$c->conexion();

	$sql="SELECT id_usuario,
				 nombre,
				 apellido,
				 email
			from usuarios where ver != '0'";
	$result=mysqli_query($conexion,$sql);

 ?>

<table  class="table table-hover table-condensered table-striped" style="text-align: center;">
	<caption><label>Usuarios</label></caption>
	<tr>
		<th>Nombre</th>
		<th>Apellido</th>
		<th>Usuario</th>
		<th>Editar</th>
		<th>Eliminar</th>
	</tr>

<?php while($ver=mysqli_fetch_row($result)):  ?>

	<tr>
		<td><?php echo $ver[1];  ?></td>
		<td><?php echo $ver[2];  ?></td>
		<td><?php echo $ver[3];  ?></td>
		<td>
			<span data-toggle="modal" data-target="#actualizaUsuarioModal" class="btn btn-warning btn-xs" onclick="agregaDatosUsuario('<?php echo $ver[0]; ?>')">
				<span class="glyphicon glyphicon-pencil"></span>
			</span>
			  	
		</td>
		 
		<?php  if($ver[0] != 1): ?>
		<td>
			<span class="btn btn-danger btn-xs" onclick="ocultarUsuario('<?php echo $ver[0]; ?>')">
				<span class="glyphicon glyphicon-remove" ></span>
			</span>
		</td>
	<?php endif; ?>
		<!--<td>
			<span class="btn btn-danger btn-xs" onclick="eliminarUsuario('<?php echo $ver[0]; ?>')">
				<span class="glyphicon glyphicon-remove" ></span>
			</span>
		</td> -->
	</tr>
	<?php endwhile; ?>

</table>