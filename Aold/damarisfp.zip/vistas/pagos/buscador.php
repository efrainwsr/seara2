<?php 
require_once "../../clases/Conexion.php";
$obj = new conectar();
$conexion= $obj->conexion();

$sql="SELECT id_residencia,
nombre,
id_cliente,
ver
from residencia";
$result=mysqli_query($conexion,$sql); 

/*
$json= file_get_contents("https://s3.amazonaws.com/dolartoday/data.json");
	$datos=json_decode($json, true);
	$dolar = $datos["USD"]["promedio"];
	//var_dump($dolar);

*/


?>
<div class="row">
	

	<div class="col-sm-1">
		<span  class="btn btn-primary btn-sm" data-toggle="modal" data-target="#abremodalAgregarPago">
			<span class="glyphicon glyphicon-plus"></span>
		</span>

	</div>
		<div class="col-sm-1"></div>

	<div class="col-sm-1">
		<label>Dolares</label>
		<p><?php echo $dol=5+5;  ?></p>
	</div>
		<div class="col-sm-1"></div>

	<div class="col-sm-2">
		<label>Bs.</label>
		<p><?php echo $bs=5+5;  ?></p>
	</div>

	<div class="col-sm-2">
		<label>Tasa actual</label>
		<p><?php //echo $dolar;  ?></p>
	</div>


	<div class="col-sm-3">
		<label>Buscador</label>
		<select id="buscadorvivo2" class="form-control input-sm">
			<option value="0">Seleciona uno</option>
			<?php
			while($ver=mysqli_fetch_row($result)): 
				?>
				<?php if($ver[3] !='1'): ?>
					<option value="<?php echo $ver[0] ?>">
						<?php echo $ver[1]." - ".$ver[2]."   INACTIVO"; ?>
					</option>
					<?php elseif($ver[3]=='1'): ?>
						<option value="<?php echo $ver[0] ?>">
							<?php echo $ver[1]." - ".$ver[2]; ?>
						</option>
					<?php endif; ?>

				<?php endwhile; ?>

			</select>
		</div>
	</div>


	<script type="text/javascript">
		$(document).ready(function(){
			$('#buscadorvivo2').select2();

			$('#buscadorvivo2').change(function(){
				$.ajax({
					type:"post",
					data:'valor=' + $('#buscadorvivo2').val(),
					url:'residencias/crearsession.php',
					success:function(r){
						$('#tablaResidenciasLoad').load('residencias/tablaResidencias.php');
					}
				});
			});
		});
	</script>

	