<?php 

session_start();

if(isset($_SESSION['usuario'])){
	

	//$dolartoday="https://s3.amazonaws.com/dolartoday/data.json";
	$json= file_get_contents("https://s3.amazonaws.com/dolartoday/data.json");
	$datos=json_decode($json, true);
	$dolar = round($datos["USD"]["promedio"]);
	$fecha = $datos["_timestamp"]["fecha"];
?>


	<!DOCTYPE html>
	<html>
	<head>
		<title>Pagos</title>
		<!-- Mostrar en lista desplegable. aqui conecta a la base y manda a un result los datos.
			Luego agregar un while para mostrar en el option.... Linea 35 -->
			<?php require_once "menu.php"; ?>
			<?php require_once "../clases/Conexion.php"; 
			$c= new conectar();
			$conexion=$c->conexion();
			$sql="SELECT id_empleado,nombre
			from empleados";
			$result=mysqli_query($conexion,$sql); 
			?>
			<!--Fin de la conexion -->

		</head>
		<body>

			<div class="container">
				<h1>Pagos</h1>
				<div id="buscador"></div>
				<div class="row">
					
					<div class="col-sm-12">
						<div id="tablaPagosLoad"></div>

					</div>
				</div>
			</div>


			<!-- Modal AGREGAR -->
			<div class="modal fade" id="abremodalAgregarPago" role="dialog" aria-labelledby="myModalLabel">
				<div class="modal-dialog modal-sm" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							<h4 class="modal-title" id="myModalLabel">Agregar Pago</h4>
						</div>
						<div class="modal-body">
							<form id="frmAgregarPago" name="frmAgregarPago" enctype="multipart/form-data">
								
								<input type="text" hidden="" readonly="" id="idpago" name="idpago">

								<label>Residencia</label>
								<select class="form-control input-sm" id="residencia" name="residencia">
									<option value="0">Seleccione un cliente</option>
									<?php 
									$sql="SELECT r.id_residencia,
									r.nombre,
									cli.nombre
									from residencia r, cliente cli 
									where r.id_cliente=cli.id_cliente AND r.ver !='0'";
									$result=mysqli_query($conexion,$sql);
									while ($residencia=mysqli_fetch_row($result)):
										?>
										<option value="<?php echo $residencia[0]?>"><?php echo $residencia[1]." - ".$residencia[2] ?></option>
									<?php endwhile; ?>
								</select>

								<label>Fecha</label>
								<br>
								<input type="date" name="fecha" step="1" min="2020-01-01" value="<?php echo date("Y-m-d");?>">
								<div id="mensaje22" class="errores"> Campo Requerido</div>
								<br>


								<label>Banco</label>
								<select class="form-control input-sm" id="bancoE" name="bancoE">
									<option value="0">Banco emisor</option>
									<option value="0">Banca amiga</option>
									<option value="0">BNC</option>
									<option value="0">Bicentenario</option>
									<option value="0">Venezolano de credito</option>
									<option value="0">Venezuela</option>
								</select>

								<label>Banco</label>
								<select class="form-control input-sm" id="bancoR" name="bancoR">
									<option value="0">Banco emisor</option>
									<option value="0">Banca amiga</option>
									<option value="0">BNC</option>
									<option value="0">Bicentenario</option>
									<option value="0">Venezolano</option>
									<option value="0">Venezuela</option>
								</select>


								<label>Referencia</label>
								<input type="text" class="form-control input-sm positive-integer" id="referencia" name="referencia" maxlength="20" placeholder="Ejemplo 004548">
								<div id="mensaje33" class="errores"> Campo Requerido</div>

								<br>
								<label>Pago en: </label>
								<div >
									<label class="checkbox-inline">
										<input type="checkbox" name="cdolar" id="cdolar" value="1" onclick="ponerReadOnly('bs')" onclick="quitarReadOnly('dolares')">Dolar
									</label>
									<label class="checkbox-inline">
										<input type="checkbox"  name="cbs" id="cbs" value="0" onclick="ponerReadOnly('dolares')" onclick="quitarReadOnly('bs')">Bs
									</label>
								</div>
								<br>

								<a style="text-decoration: none;" href="https://www.instagram.com/enparalelovzla/?hl=es-la" target="_blank"><p><strong>Tasa: </strong><i><?php echo $fecha; ?></i></p></a>
								<input type="text" maxlength="7" class="form-control input-sm  decimal-2-places" id="tasa" name="tasa" placeholder="Ejemplo 500120" value="<?php echo $dolar ?>">
								<div id="mensaje44" class="errores" > Campo Requerido</div>

								<label>Dolares</label>			
								<input type="text" maxlength="7" class="form-control input-sm decimal-2-places" id="dolares" name="dolares" placeholder="Ejemplo, 80">
								<div id="mensaje55" class="errores"> Campo Requerido</div>

								<label>Bolivares</label>
								<input type="text" maxlength="15" class="form-control input-sm decimal-2-places" id="bs" name="bs" placeholder="Ejemplo 155999">
								<div id="mensaje55" class="errores"> Campo Requerido</div>
							</form>
						</div>
						<div class="modal-footer">
							<button id="btnAgregaPago" type="button" class="btn btn-primary" data-dismiss="modal">Agregar</button>

						</div>
					</div>
				</div>
			</div>


			<!-- Modal EDITAR -->
			<div class="modal fade" id="abremodalUpdateVehiculo" role="dialog" aria-labelledby="myModalLabel">
				<div class="modal-dialog modal-sm" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							<h4 class="modal-title" id="myModalLabel">Actualiza Vehiculo</h4>
						</div>
						<div class="modal-body">
							<form id="frmVehiculoU" name="frmVehiculoU" enctype="multipart/form-data">
								<label>Placa</label>
								<input type="text" readonly="" class="form-control input-sm" id="idVehiculo" name="idVehiculo" placeholder="Ejemplo, GHG 8HJU">

								<label>Capacidad</label>
								<input type="text" maxlength="7" class="form-control input-sm decimal-2-places" id="capacidadU" name="capacidadU" placeholder="Ejemplo, 1500">
								<div id="mensaje11" class="errores"> Campo Requerido</div>

								<label>Marca</label>
								<input type="text" class="form-control input-sm" id="marcaU" name="marcaU" placeholder="Ejemplo, FORD">
								<div id="mensaje22" class="errores"> Campo Requerido</div>
								<label>modelo</label>
								<input type="text" class="form-control input-sm" id="modeloU" name="modeloU" placeholder="Ejemplo, F-150">
								<div id="mensaje33" class="errores"> Campo Requerido</div>
								<label>ruedas</label>
								<input type="text" maxlength="2" class="form-control input-sm positive decimal-2-places" id="ruedasU" name="ruedasU" placeholder="Ejemplo, 4">
								<div id="mensaje44" class="errores"> Campo Requerido</div>
								<label>Rin</label>
								<input type="text" maxlength="2" class="form-control input-sm positive-integer" id="rinU" name="rinU" placeholder="Ejemplo, 16">
								<div id="mensaje55" class="errores"> Campo Requerido</div>

							</form>
						</div>
						<div class="modal-footer">
							<button id="btnActualizavehiculo" type="button" class="btn btn-warning" data-dismiss="modal">Actualizar</button>

						</div>
					</div>
				</div>
			</div>


		</body>
		</html>

		<script type="text/javascript">
			function agregaDatosVehiculo(idvehiculo){
				$.ajax({
					type:"POST",
					data:"idvehi=" + idvehiculo,
					url:"../procesos/vehiculos/obtenDatosVehiculo.php",
					success:function(r){
						
						dato=jQuery.parseJSON(r);
						$('#idVehiculo').val(dato['id_vehiculo']);
						//$('#empleadoSelectU').val(dato['id_empleado']);
						$('#placaU').val(dato['placa']);
						$('#capacidadU').val(dato['capacidad']);
						$('#marcaU').val(dato['marca']);
						$('#modeloU').val(dato['modelo']);
						$('#ruedasU').val(dato['cant_ruedas']);
						$('#rinU').val(dato['rin']);
						//$('#placaU').val(dato['placa']);


					}
				});
			}

			function eliminaVehiculo(idvehiculo){
				alertify.confirm('Desea eliminar este vehiculo?', function(){ 
					$.ajax({
						type:"POST",
						data:"idvehiculo=" + idvehiculo,
						url:"../procesos/vehiculos/eliminarVehiculo.php",
						success:function(r){
							if(r==1){
								$('#tablaVehiculosLoad').load("vehiculos/tablaVehiculos.php");
								alertify.success("Eliminado con exito!");
							}else{
								alertify.error("No se pudo eliminar");
								alert(r);
							}
						}
					}); 
				}, function(){ alertify.error('Cancelado')
			});

			}

		</script>

		<script type="text/javascript">
			$(document).ready(function(){
				$('#btnActualizavehiculo').click(function(){

					vacios=validarFormVacio('frmVehiculoU');

					if(vacios > 0){
						//alertify.alert("Debes llenar todos los campos!");
						return false;
					}

					datos=$('#frmVehiculoU').serialize();
					$.ajax({
						type:"POST",
						data:datos,
						url:"../procesos/vehiculos/actualizaVehiculos.php",
						success:function(r){
							if(r==1){
								$('#tablaVehiculosLoad').load("vehiculos/tablaVehiculos.php");
								alertify.success("Actualizado con exito.");
							}else{
								alert(r);
								alertify.error("Error al actualizar.");
							}
						}
					});
				});
			});
		</script>


		<script type="text/javascript">
			$(document).ready(function(){

				$('#tablaPagosLoad').load('pagos/tablaPagos.php');

				$('#btnAgregaPago').click(function(){

					//$("#cdolar").prop("checked", true);

				/*vacios=validarFormVacio('frmAgregarPago');
			
				
				if(vacios > 0){
					//alertify.alert("Debes llenar todos los campos!");
					return false;
				} */


				$("#bs").prop("disabled", false);
				$("#dolares").prop("disabled", false);

				datos=$('#frmAgregarPago').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../procesos/pagos/agregaPago.php",
					success:function(r){
						//alert(r);

						if(r==1){
							$('#frmAgregarPago')[0].reset();
							$('#tablaPagosLoad').load('pagos/tablaPagos.php');
							alertify.success("Agregado con exito.");
							$("#dolares").removeAttr("readonly");
							$("#bs").removeAttr("readonly");
						}else{
							alertify.error("Fallo al registrar pago.");
							alert(r);
						}
					}
				});
			});
			});
		</script>


		<script type="text/javascript">

			$(document).ready(function(){
				validarNumeros()
			});

			function validarNumeros(){
				$(".numeric").numeric();
				$(".integer").numeric(false, function() { alert("Integers only"); this.value = ""; this.focus(); });
				$(".positive").numeric({ negative: false }, function() { alert("No negative values"); this.value = ""; this.focus(); });
				$(".positive-integer").numeric({ decimal: false, negative: false }, function() { alert("Positive integers only"); this.value = ""; this.focus(); });
				$(".decimal-2-places").numeric({ decimalPlaces: 2 });
				$(".decimal-3-places").numeric({ decimalPlaces: 3 });
				$("#remove").click(
					function(e)
					{
						e.preventDefault();
						$(".numeric,.integer,.positive,.positive-integer,.decimal-2-places").removeNumeric();
					}
					);
			}
		</script>
		<script type="text/javascript">
			soloLetras();
		</script>
		
		<script>
			$(document).ready(function(){
            //función click
            $("#btnAgregaVehiculo").click(function(){
            	var placa = $("#placa").val();
            	var capacidad = $("#capacidad").val();
            	var marca = $("#marca").val();
            	var modelo = $("#modelo").val();
            	var ruedas = $("#ruedas").val();
            	var rin = $("#rin").val();

            	if(placa == ""){
            		$("#mensaje1").fadeIn("slow");
            		document.frmVehiculos.placa.focus()
            		return false;
            	}else{
            		$("#mensaje1").fadeOut();
            	}
            	if(capacidad == ""){
            		$("#mensaje2").fadeIn("slow");
            		document.frmVehiculos.capacidad.focus()
            		return false;
            	}
            	else{
            		$("#mensaje2").fadeOut();
            	}
            	if(marca == ""){
            		$("#mensaje3").fadeIn("slow");
            		document.frmVehiculos.marca.focus()
            		return false;
            	}
            	else{
            		$("#mensaje3").fadeOut();
            	}
            	if(modelo == ""){
            		$("#mensaje4").fadeIn("slow");
            		document.frmVehiculos.modelo.focus()
            		return false;
            	}
            	else{
            		$("#mensaje4").fadeOut();
            	}
            	if(ruedas == ""){
            		$("#mensaje5").fadeIn("slow");
            		document.frmVehiculos.ruedas.focus()
            		return false;
            	}
            	else{
            		$("#mensaje5").fadeOut();
            	}
            	if(rin == ""){
            		$("#mensaje6").fadeIn("slow");
            		document.frmVehiculos.rin.focus()
            		return false;
            	}
            	else{
            		$("#mensaje6").fadeOut();
            	}

            });//click
       });//ready
   </script>

   <script>
   	$(document).ready(function(){
            //función click
            $("#btnActualizavehiculo").click(function(){
                //var placa = $("#placa").val();
                var capacidadU = $("#capacidadU").val();
                var marcaU = $("#marcaU").val();
                var modeloU = $("#modeloU").val();
                var ruedasU = $("#ruedasU").val();
                var rinU = $("#rinU").val();

                if(capacidadU == ""){
                	$("#mensaje11").fadeIn("slow");
                	document.frmVehiculoU.capacidadU.focus()
                	return false;
                }
                else{
                	$("#mensaje11").fadeOut();

                	if(marcaU == ""){
                		$("#mensaje22").fadeIn("slow");
                		document.frmVehiculoU.marcaU.focus()
                		return false;
                	}
                	else{
                		$("#mensaje22").fadeOut();
                	}
                	if(modeloU == ""){
                		$("#mensaje33").fadeIn("slow");
                		document.frmVehiculoU.modeloU.focus()
                		return false;
                	}
                	else{
                		$("#mensaje33").fadeOut();
                	}
                	if(ruedasU == ""){
                		$("#mensaje44").fadeIn("slow");
                		document.frmVehiculoU.ruedasU.focus()
                		return false;
                	}
                	else{
                		$("#mensaje44").fadeOut();
                	}
                	if(rinU == ""){
                		$("#mensaje55").fadeIn("slow");
                		document.frmVehiculoU.rinU.focus()
                		return false;
                	}
                	else{
                		$("#mensaje55").fadeOut();
                	}
                }
            });//click
       });//ready
   </script>

   <script type="text/javascript">
   	$(document).ready(function(){
   		$('#tabla').load('pagos/tablaPagos.php');
   		$('#buscador').load('pagos/buscador.php');
   	});
   </script>

   <script type="text/javascript"> 									//SELECT2
   	$(document).ready(function(){
   		$('#residencia').select2({
   			width: '100%',
   			dropdownParent: $('#abremodalAgregarPago')
   		});

   			$('#bancoE').select2({
   			width: '100%',
   			dropdownParent: $('#abremodalAgregarPago')
   		});
   			$('#bancoR').select2({
   			width: '100%',
   			dropdownParent: $('#abremodalAgregarPago')
   		});

   	});

   </script>


<script>
	
	/*
	 function ponerReadOnly(id)
    {
        // Ponemos el atributo de solo lectura
        $("#"+id).attr("readonly","readonly");

    }

     function quitarReadOnly(id)
    {
        // Eliminamos el atributo de solo lectura
        $("#"+id).removeAttr("readonly");
    }
*/
</script>


 

   <script type="text/javascript">     // FUNCIONES PARA EL CHECKBOX

   	$("#cdolar").on("click", function() {  
   		if ($("#cdolar").length == $("#cdolar:checked").length) {  
   			$("#cbs").prop("checked", false);
   			$("#bs").attr("readonly","readonly"); // nuevo
   			$("#dolares").removeAttr("readonly"); // nuevo
   			//$("#bs").prop("disabled", true);        // anterior 
   			//$("#dolares").prop("disabled", false); // anterior
   			$("#bs").val(" ");
   		} else {
   			//$("#bs").prop("disabled", false);
   			$("#bs").removeAttr("readonly");
   			 
   		}  
   	});

   	$("#cbs").on("click", function() {  
   		if ($("#cbs").length == $("#cbs:checked").length) {  
   			$("#cdolar").prop("checked", false);
   			$("#dolares").attr("readonly","readonly"); // nuevo
   			$("#bs").removeAttr("readonly"); // nuevo
   			//$("#bs").prop("disabled", false);		//anterior
   			//$("#dolares").prop("disabled", true);   //anterior
   			$("#dolares").val(" ");
   		} else {  
   			//$("#dolares").prop("disabled", false);
   			$("#dolares").removeAttr("readonly");
   			  
   		}  
   	});


   </script>


   <?php


}else{
	header("location:../index.php");
}

?>

