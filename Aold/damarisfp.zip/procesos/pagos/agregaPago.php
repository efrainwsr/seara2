<?php 

session_start();

require_once "../../clases/Conexion.php";
require_once "../../clases/Pagos.php";

$obj= new pagos();

$fecha=strtotime($_POST['fecha']);
$fecha = date('Y-m-d',$fecha);


$dolares=$_POST['dolares'];
$bs=$_POST['bs'];
$tasa=$_POST['tasa'];


if((empty($dolares) || $dolares==" ") && (empty($bs) || $bs==" " )) {
	echo "Ingrese una cantidad de dolares o bolivares.";
	
	}
	else{

		if($dolares==" "){
			$dolares=$bs/$tasa;

			}elseif($bs==" "){
				$bs=$dolares*$tasa;
			}
	}

if($_POST['residencia']=="0"){
	echo "Seleccione un cliente";
}else{
	$datos=array(
	$_POST['residencia'],
	$fecha,
	$_POST['referencia'],
	$tasa,
	$dolares,
	$bs);

echo $obj->agregaPago($datos);
}

?>