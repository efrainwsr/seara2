<?php 

session_start();

	require_once "../../clases/Conexion.php";
	require_once "../../clases/Residencias.php";

	$obj= new residencias();

	$datos=array(
		$_POST['conjunto'],
		$_POST['casas'],
		$_POST['kgbasura'],
		$_POST['pago'],
		$_POST['direccion'],
		$_POST['clienteR'],
		$_POST['gmap'],
		$_POST['latitud'],
		$_POST['longitud']

	);

	echo $obj->agregaResidencia($datos);


	
 ?>