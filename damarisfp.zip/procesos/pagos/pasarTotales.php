<?php 

session_start();

$_SESSION['TOTALDOLARES']  = $_POST["totaldolares"];
$_SESSION['TOTALBS'] = $_POST["totalbs"];

?>