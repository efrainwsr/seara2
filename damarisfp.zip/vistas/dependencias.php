<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<link rel="stylesheet" type="text/css" href="../librerias/alertifyjs/css/alertify.css">
<link rel="stylesheet" type="text/css" href="../librerias/alertifyjs/css/themes/default.css">
<link rel="stylesheet" type="text/css" href="../librerias/bootstrap/css/bootstrap.css">

<link rel="stylesheet" type="text/css" href="../librerias/select2/css/select2.css">
<link rel="stylesheet" type="text/css" href="../css/menu.css">
<link rel="stylesheet" href="../css/tabla.css">
 <link rel="shortcut icon" href="../img/favicon.png" />
 <script src="../librerias/fontawesome.js"></script>
 

<!--  Importar waves -->
<!--<link rel="stylesheet" href="../css/ripple.css">
<script src="../js/ripple.js"></script> -->
<script src="../librerias/jquery-3.2.1.min.js"></script>
<script src="../librerias/jquery.validate.min.js"></script>
<script src="../librerias/alertifyjs/alertify.js"></script>
<script src="../librerias/bootstrap/js/bootstrap.js"></script>
<script src="../librerias/select2/js/select2.js"></script>
<script src="../js/funciones.js"></script>
<script src="../librerias/jqueryNumeric/jquery.numeric.js"></script>
<link rel="stylesheet" type="text/css" href="../librerias/selectr/selectr.min.css">
<script src="../librerias/selectr/selectr.min.js"></script>
<script src="../librerias/twbspagination/jquery.twbsPagination.js"></script>
<script src="../librerias/pushjs/push.min.js"></script>





							<!-- DATATABLE -->


<!-- DATATABLES -->
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>

<!-- BOOTSTRAP -->
<script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>

<link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css">
    


<!--
<script src="../js/materialize.js"></script>
<script src="../js/materialize.min.js"></script>
<link rel="stylesheet" type="text/css" href="../css/materialize.min.css">
<link rel="stylesheet" type="text/css" href="../css/materialize.css">

 -->

<!--

	<link rel="stylesheet" type="text/css" href="../vendor/animate/animate.css">
	<link rel="stylesheet" type="text/css" href="../css/main.css">
	<link rel="stylesheet" type="text/css" href="../css/util.css">
	
	<link rel="stylesheet" type="text/css" href="../vendor/css-hamburgers/hamburgers.min.css">
	<link rel="stylesheet" type="text/css" href="../vendor/animsition/css/animsition.min.css">
	<link rel="stylesheet" type="text/css" href="../vendor/daterangepicker/daterangepicker.css">
	<link rel="stylesheet" type="text/css" href="../vendor/bootstrap/css/bootstrap.min.css">

-->



